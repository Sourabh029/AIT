package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.OrderDao;
import com.example.demo.model.Order;

@Service
public class OrderService {

	@Autowired
	private OrderDao orderDao;
	
	
	public Iterable<Order> getAllOrders()
	{
		return orderDao.findAll();
	}
	
	public Order getOrderById(Integer id)
	{
		return orderDao.findById(id).orElse(new Order());
	}
	
	public Order createOrder(Order order)
	{
		return orderDao.save(order);
	}
	
	public Order updateOrder(Order order,Integer id)
	{
		Order actualOrder =  getOrderById(id);
		actualOrder.setEmail(order.getEmail());
		actualOrder.setOrderamount(order.getOrderamount());
		actualOrder.setPaymenttype(order.getPaymenttype());
		actualOrder.setPhonenumber(order.getPhonenumber());
		actualOrder.setProducts(order.getProducts());
		
		return orderDao.save(actualOrder);
	}
	
	public String deleteOrder(Integer id)
	{
		try {
		Order order = getOrderById(id);	
		orderDao.delete(order);
		return "Order with Order id"+id +" for customer "+ order.getCutomername()+"has been deleted";
		}
		catch (Exception e) {
			// TODO: handle exception
			return "Sorry there is some problem with deleting the record";
		}
		
	}
	
}
